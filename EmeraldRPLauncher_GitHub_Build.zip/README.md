# Emerald RP Android Launcher — source project

A native Android Studio starter launcher for the Emerald RP SA-MP gamemode. The UI uses the purple palette found in `emerald.pwn` (`color_main = #BB7DFF`, `color_purple = #EA8AFD`) and surfaces systems visible in the source such as GPS/help, houses/businesses, quests, jobs, and battle pass.

## Open and build
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync.
4. Build > Build APK(s). Android Studio will produce a debug APK under `app/build/outputs/apk/debug/`.

This source project is provided; an APK has not been built or tested in this environment.

## Server settings
The default host is `188.127.74` and port is `3536`, exactly as supplied. `188.127.74` is not a complete IPv4 address, so the app intentionally asks you to correct it before connecting. Enter the full IP or a domain in the launcher.

## Important connection behavior
The Play button sends an Android `ACTION_VIEW` request for `samp://HOST:PORT`. A compatible SA-MP Android client must already be installed and must register that URI scheme. The launcher does not bundle or replace the game client, and does not directly implement SA-MP's game protocol.

## Current scope
- Purple/black Emerald RP launcher UI.
- Editable server host and port.
- Optional nickname validation.
- Remembers last entered connection settings.
- Opens a compatible SA-MP Android client using a `samp://` URI.
- Explains invalid/incomplete server host and missing compatible-client handling.
- Feature cards based on systems/commands referenced by the gamemode.

## Before public release
- Verify the actual server host and whether the target Android client supports `samp://` links.
- Add a real server-status endpoint if you want live online count/status; Pawn gamemode source alone does not provide a public HTTP status API.
- Add a secure HTTPS manifest/CDN for game assets if the launcher must download or repair files.
- Do not put MySQL credentials in the launcher. The supplied Pawn file contained database credentials in plaintext; rotate that password and keep DB access server-side.
- Review package name, signing key, privacy policy, and distribution requirements before release.


## Build the APK on GitHub (phone-friendly)
1. Create a new repository on GitHub, for example `EmeraldRPLauncher`.
2. Upload the **contents** of this folder into the repository root (so `app/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/` are at the top level).
3. Open the repository's **Actions** tab and select **Build Emerald RP Android APK**.
4. Tap **Run workflow** if it has not started automatically.
5. Open the completed run, scroll to **Artifacts**, and download `EmeraldRP-debug-apk`.
6. Extract the artifact ZIP; inside is `app-debug.apk`.

The workflow uses Java 17, Android SDK 35, and Gradle 8.9. The result is a debug APK for testing, not a signed release APK.
