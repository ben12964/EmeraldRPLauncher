EMERALD RP ANDROID APK BUILD PACKAGE

1. Keep EmeraldRPLauncher_GitHub_Build.zip in the ROOT of your GitHub repository.
2. In GitHub, open .github/workflows/emerald-android.yml and replace its entire contents with the supplied emerald-android.yml.
3. Commit the change.
4. Open Actions > Emerald RP APK Build > Run workflow.
5. When successful, download the EmeraldRP-Android-APK artifact and extract app-debug.apk.

The workflow YAML was syntax-validated. The APK itself has NOT been compiled in this environment because Android SDK/Gradle are not installed here. The workflow compiles it on GitHub Actions.
