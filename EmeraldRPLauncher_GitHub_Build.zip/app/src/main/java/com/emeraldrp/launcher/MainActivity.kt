package com.emeraldrp.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.InputType
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 11, 25)
    private val panel = Color.rgb(31, 22, 45)
    private val purple = Color.rgb(187, 125, 255)
    private val palePurple = Color.rgb(234, 138, 253)
    private val white = Color.rgb(247, 242, 255)
    private val muted = Color.rgb(177, 164, 194)
    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var nickInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "E"
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(bg)
            background = shape(purple, 18)
            layoutParams = LinearLayout.LayoutParams(dp(58), dp(58))
        }
        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        brand.addView(text("EMERALD RP", 22f, white, true))
        brand.addView(text("ROLEPLAY • ANDROID CLIENT", 11f, muted, true))
        top.addView(logo)
        top.addView(brand)
        root.addView(top)
        root.addView(space(24))

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = shape(panel, 22)
        }
        hero.addView(text("YOUR CITY. YOUR STORY.", 23f, white, true))
        hero.addView(space(8))
        hero.addView(text("Enter the world of Emerald RP. Choose your identity, connect to the city, and write your own roleplay story.", 14f, muted, false))
        hero.addView(space(16))
        val tag = TextView(this).apply {
            text = "●  PURPLE EDITION"
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(palePurple)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = shape(Color.rgb(57, 32, 77), 30)
        }
        hero.addView(tag, LinearLayout.LayoutParams(-2, -2))
        root.addView(hero)
        root.addView(space(22))

        root.addView(sectionTitle("CONNECT TO SERVER"))
        root.addView(space(10))
        val connection = card()
        connection.addView(fieldLabel("SERVER ADDRESS"))
        hostInput = edit("188.127.74", "IP address or domain", InputType.TYPE_CLASS_TEXT)
        connection.addView(hostInput, matchWrap())
        connection.addView(space(12))
        connection.addView(fieldLabel("SERVER PORT"))
        portInput = edit("3536", "Port", InputType.TYPE_CLASS_NUMBER)
        connection.addView(portInput, matchWrap())
        connection.addView(space(12))
        connection.addView(fieldLabel("PLAYER NICKNAME"))
        nickInput = edit("", "Example: Emerald_Player", InputType.TYPE_CLASS_TEXT)
        connection.addView(nickInput, matchWrap())
        connection.addView(space(16))
        val play = Button(this).apply {
            text = "CONNECT & PLAY"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(24, 12, 36))
            background = shape(purple, 14)
            isAllCaps = false
            setOnClickListener { connectToGame() }
        }
        connection.addView(play, LinearLayout.LayoutParams(-1, dp(54)))
        connection.addView(space(10))
        status = text("Ready. Check the server address before connecting.", 12f, muted, false)
        connection.addView(status)
        root.addView(connection)
        root.addView(space(22))

        root.addView(sectionTitle("ROLEPLAY FEATURES"))
        root.addView(space(10))
        feature(root, "⌂", "HOUSES & BUSINESSES", "Explore property and business roleplay systems.")
        feature(root, "✦", "QUESTS & BATTLE PASS", "Track progression through the in-game quest and battle-pass systems.")
        feature(root, "⌖", "GPS & CITY SERVICES", "Use the in-game GPS and help commands after joining.")
        feature(root, "♙", "JOBS & COMMUNITY", "Discover jobs and connect with other players.")
        root.addView(space(18))
        root.addView(text("CLIENT NOTE", 12f, palePurple, true))
        root.addView(space(6))
        root.addView(text("This launcher opens a compatible SA-MP Android client if one is installed. It does not install game assets or guarantee server availability. The address currently entered has only three IPv4 sections, so confirm the complete host before connecting.", 12f, muted, false))
        root.addView(space(16))
        root.addView(text("EMERALD RP  •  VERSION 1.0.0", 10f, muted, true).apply { gravity = Gravity.CENTER })
    }

    private fun connectToGame() {
        val host = hostInput.text.toString().trim()
        val portText = portInput.text.toString().trim()
        val nick = nickInput.text.toString().trim()

        if (host.isBlank()) { status.text = "Enter the server address first."; return }
        if (host.matches(Regex("""\d{1,3}(\.\d{1,3}){2}"""))) {
            status.text = "The IP looks incomplete. Enter all four IPv4 sections or a domain name."
            return
        }
        if (host.matches(Regex("""\d{1,3}(\.\d{1,3}){3}""")) &&
            host.split(".").any { it.toIntOrNull() == null || it.toInt() !in 0..255 }) {
            status.text = "That IPv4 address is invalid."
            return
        }
        val port = portText.toIntOrNull()
        if (port == null || port !in 1..65535) { status.text = "Enter a valid port from 1 to 65535."; return }
        if (nick.isNotBlank() && !nick.matches(Regex("[A-Za-z0-9_]{3,24}"))) {
            status.text = "Nickname must be 3–24 letters, numbers, or underscores."
            return
        }

        getSharedPreferences("emerald_launcher", MODE_PRIVATE).edit()
            .putString("host", host).putString("port", portText).putString("nickname", nick).apply()

        val uri = Uri.parse("samp://$host:$port")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        try {
            startActivity(intent)
            status.text = "Sent connection request to an installed compatible client."
        } catch (_: Exception) {
            status.text = "No app handled samp:// links. Install/configure a compatible SA-MP Android client."
        }
    }

    private fun feature(parent: LinearLayout, symbol: String, title: String, desc: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = shape(panel, 16)
        }
        val icon = TextView(this).apply {
            text = symbol; textSize = 23f; gravity = Gravity.CENTER; setTextColor(purple)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        copy.addView(text(title, 13f, white, true))
        copy.addView(space(4))
        copy.addView(text(desc, 12f, muted, false))
        row.addView(icon)
        row.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        parent.addView(row)
        parent.addView(space(9))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = shape(panel, 20)
    }
    private fun sectionTitle(s: String) = text(s, 13f, palePurple, true)
    private fun fieldLabel(s: String) = text(s, 10f, muted, true).apply { setPadding(0, dp(2), 0, dp(7)) }
    private fun edit(value: String, hintText: String, type: Int) = EditText(this).apply {
        setText(value); hint = hintText; inputType = type
        textSize = 14f; setTextColor(white); setHintTextColor(Color.rgb(119, 105, 137))
        setSingleLine(true); setPadding(dp(13), 0, dp(13), 0)
        background = shape(Color.rgb(22, 16, 32), 12)
        minHeight = dp(48)
    }
    private fun text(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(-1, dp(48))
    private fun shape(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
